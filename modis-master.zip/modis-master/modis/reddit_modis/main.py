def start():
    print("Modis for Reddit is in development")
