modulename = "Replies"

sd_structure = {
    "activated": True,
    "normal": {},
    "tts": {}
}
