modulename = "Music"
modulecolor = 0x282b30
modulecolor_info = 0xAAFF00
modulecolor_error = 0xFF5555

sd_structure = {
    "activated": True,
    "topic_id": ""
}

cache = {}
