modulename = "Hex"

sd_structure = {
    "activated": True
}
