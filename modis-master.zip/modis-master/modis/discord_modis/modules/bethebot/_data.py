modulename = "BeTheBot"

sd_structure = {
    "activated": True
}
