modulename = "Manager"

sd_structure = {}
