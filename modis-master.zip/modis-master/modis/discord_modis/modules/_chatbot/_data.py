modulename = "ChatBot"

sd_structure = {
    "activated": True,
    "channels": []
}
