modulename = "Tableflip"

sd_structure = {
    "activated": True
}
