modulename = "RocketLeague"

sd_structure = {
    "activated": True
}
