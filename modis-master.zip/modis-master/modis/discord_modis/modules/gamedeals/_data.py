modulename = "Gamedeals"

sd_structure = {
    "activated": True
}
